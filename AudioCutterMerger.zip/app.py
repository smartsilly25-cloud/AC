import os
import queue
import re
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import core

FILETYPES = [("Audio", "*.mp3 *.wav *.m4a *.mp4a *.aac *.mp4"), ("Semua file", "*.*")]
FORMATS = {"Sama dengan file pertama": None, "MP3": ".mp3", "WAV": ".wav", "M4A": ".m4a"}


def natural_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def open_folder(path):
    if sys.platform.startswith("win"):
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Pemotong & Penggabung Audio")
        self.geometry("780x660")
        self.minsize(680, 580)
        self.q = queue.Queue()
        self.cancel = threading.Event()
        self.busy = False
        self.files = []
        self.cut_file = tk.StringVar()
        self.seg_min = tk.StringVar(value="5")
        self.fmt = tk.StringVar(value="Sama dengan file pertama")
        self.status = tk.StringVar(value="Siap.")

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=False, padx=10, pady=(10, 4))
        self._build_cut(nb)
        self._build_merge(nb)

        bottom = ttk.Frame(self)
        bottom.pack(fill="both", expand=True, padx=10, pady=(4, 10))
        self.pb = ttk.Progressbar(bottom, maximum=100)
        self.pb.pack(fill="x")
        ttk.Label(bottom, textvariable=self.status).pack(anchor="w", pady=(4, 4))
        self.logbox = tk.Text(bottom, height=8, state="disabled", wrap="word")
        self.logbox.pack(fill="both", expand=True)
        row = ttk.Frame(bottom)
        row.pack(fill="x", pady=(6, 0))
        self.btn_cancel = ttk.Button(row, text="Batal", command=self.cancel.set, state="disabled")
        self.btn_cancel.pack(side="left")
        ttk.Button(row, text="Buka Folder Hasil",
                   command=lambda: open_folder(core.result_dir())).pack(side="right")
        ttk.Label(row, text="Hasil disimpan di: " + os.path.join(core.app_dir(), "Hasil"),
                  foreground="#555").pack(side="right", padx=10)
        self.after(100, self._poll)

    # ---------- UI ----------
    def _build_cut(self, nb):
        f = ttk.Frame(nb, padding=14)
        nb.add(f, text="  Pemotong  ")
        ttk.Label(f, text="File audio (.mp3 / .wav / .m4a):").grid(row=0, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.cut_file, state="readonly").grid(
            row=1, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(f, text="Pilih File...", command=self.pick_cut).grid(row=1, column=1)
        ttk.Label(f, text="Durasi maksimal per bagian (menit, bisa desimal):").grid(
            row=2, column=0, sticky="w", pady=(14, 0))
        ttk.Spinbox(f, from_=0.1, to=1000, increment=0.5, textvariable=self.seg_min,
                    width=8).grid(row=3, column=0, sticky="w")
        self.btn_cut = ttk.Button(f, text="Mulai Potong", command=self.start_cut)
        self.btn_cut.grid(row=4, column=0, sticky="w", pady=(14, 0))
        f.columnconfigure(0, weight=1)

    def _build_merge(self, nb):
        f = ttk.Frame(nb, padding=14)
        nb.add(f, text="  Penggabung  ")
        ttk.Label(f, text="Daftar file (urutan atas ke bawah = urutan gabungan):").grid(
            row=0, column=0, columnspan=2, sticky="w")
        self.lb = tk.Listbox(f, selectmode="extended", height=8)
        self.lb.grid(row=1, column=0, sticky="nsew")
        sb = ttk.Scrollbar(f, command=self.lb.yview)
        sb.grid(row=1, column=1, sticky="ns")
        self.lb.config(yscrollcommand=sb.set)
        btns = ttk.Frame(f)
        btns.grid(row=1, column=2, sticky="n", padx=(8, 0))
        for text, cmd in [("Tambah File...", self.add_files), ("Hapus", self.remove_sel),
                          ("Naik", lambda: self.move(-1)), ("Turun", lambda: self.move(1)),
                          ("Urutkan Nama", self.sort_names), ("Kosongkan", self.clear_files)]:
            ttk.Button(btns, text=text, command=cmd).pack(fill="x", pady=2)
        opt = ttk.Frame(f)
        opt.grid(row=2, column=0, columnspan=3, sticky="w", pady=(10, 0))
        ttk.Label(opt, text="Format hasil:").pack(side="left")
        ttk.Combobox(opt, textvariable=self.fmt, values=list(FORMATS), state="readonly",
                     width=24).pack(side="left", padx=8)
        self.btn_merge = ttk.Button(f, text="Mulai Gabung", command=self.start_merge)
        self.btn_merge.grid(row=3, column=0, sticky="w", pady=(10, 0))
        f.columnconfigure(0, weight=1)

    # ---------- daftar file ----------
    def refresh(self):
        self.lb.delete(0, "end")
        for i, p in enumerate(self.files, 1):
            self.lb.insert("end", f"{i}. {os.path.basename(p)}")

    def add_files(self):
        for p in filedialog.askopenfilenames(title="Pilih file audio", filetypes=FILETYPES):
            self.files.append(p)
        self.refresh()

    def remove_sel(self):
        for i in reversed(self.lb.curselection()):
            del self.files[i]
        self.refresh()

    def clear_files(self):
        self.files.clear()
        self.refresh()

    def sort_names(self):
        self.files.sort(key=lambda p: natural_key(os.path.basename(p)))
        self.refresh()

    def move(self, d):
        sel = list(self.lb.curselection())
        if not sel:
            return
        if d < 0:
            if sel[0] == 0:
                return
            for i in sel:
                self.files[i - 1], self.files[i] = self.files[i], self.files[i - 1]
            new = [i - 1 for i in sel]
        else:
            if sel[-1] == len(self.files) - 1:
                return
            for i in reversed(sel):
                self.files[i + 1], self.files[i] = self.files[i], self.files[i + 1]
            new = [i + 1 for i in sel]
        self.refresh()
        for i in new:
            self.lb.selection_set(i)

    def pick_cut(self):
        p = filedialog.askopenfilename(title="Pilih file audio", filetypes=FILETYPES)
        if p:
            self.cut_file.set(p)

    # ---------- eksekusi ----------
    def set_busy(self, busy):
        self.busy = busy
        st = "disabled" if busy else "normal"
        self.btn_cut.config(state=st)
        self.btn_merge.config(state=st)
        self.btn_cancel.config(state="normal" if busy else "disabled")

    def run(self, fn, label):
        if self.busy:
            return
        self.cancel.clear()
        self.set_busy(True)
        self.pb["value"] = 0
        self.status.set(label)
        self.write_log("== " + label + " ==")

        def work():
            try:
                self.q.put(("done", fn()))
            except core.Cancelled:
                self.q.put(("cancel", None))
            except Exception as e:  # noqa: BLE001
                self.q.put(("error", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _cb(self):
        return dict(progress=lambda f: self.q.put(("p", f)),
                    log=lambda s: self.q.put(("l", s)),
                    cancelled=self.cancel.is_set)

    def start_cut(self):
        path = self.cut_file.get()
        if not path or not os.path.isfile(path):
            messagebox.showwarning("Pemotong", "Pilih file audio terlebih dahulu.")
            return
        try:
            minutes = float(self.seg_min.get().replace(",", "."))
            if minutes <= 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Pemotong", "Durasi per bagian harus angka lebih dari 0.")
            return
        out = core.result_dir()
        cb = self._cb()
        self.run(lambda: core.cut(path, minutes * 60, out, **cb), "Memotong audio...")

    def start_merge(self):
        if len(self.files) < 2:
            messagebox.showwarning("Penggabung", "Tambahkan minimal 2 file.")
            return
        files = list(self.files)
        fmt = FORMATS[self.fmt.get()]
        out = core.result_dir()
        cb = self._cb()
        self.run(lambda: core.merge(files, out, fmt, **cb), "Menggabungkan audio...")

    def write_log(self, s):
        self.logbox.config(state="normal")
        self.logbox.insert("end", s + "\n")
        self.logbox.see("end")
        self.logbox.config(state="disabled")

    def _poll(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "p":
                    self.pb["value"] = val * 100
                elif kind == "l":
                    self.write_log(val)
                elif kind == "done":
                    self.set_busy(False)
                    self.pb["value"] = 100
                    self.status.set("Selesai.")
                    for p in val:
                        self.write_log("Tersimpan: " + p)
                    messagebox.showinfo("Selesai", f"{len(val)} file tersimpan di folder:\n"
                                        + core.result_dir())
                elif kind == "cancel":
                    self.set_busy(False)
                    self.status.set("Dibatalkan.")
                    self.write_log("Dibatalkan.")
                elif kind == "error":
                    self.set_busy(False)
                    self.status.set("Gagal.")
                    self.write_log("ERROR: " + val)
                    messagebox.showerror("Error", val)
        except queue.Empty:
            pass
        self.after(100, self._poll)


if __name__ == "__main__":
    App().mainloop()
