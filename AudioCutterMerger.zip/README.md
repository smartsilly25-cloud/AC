# Pemotong & Penggabung Audio
- Pemotong: potong .mp3/.wav/.m4a per N menit (default 5, bisa diatur).
- Penggabung: gabung banyak file tanpa batas durasi dan tanpa jeda.
- Hasil tersimpan di folder `Hasil` di lokasi yang sama dengan aplikasi (.exe).
