"""Logika inti: potong & gabung audio tanpa jeda (gapless).

Semua audio di-decode ke PCM float32 mentah, lalu dipotong / disambung pada
batas sampel yang tepat dan di-encode ulang secara streaming. Karena itu
penyambungan tidak punya jeda dan tidak ada batas durasi (tidak memakan RAM).
"""
import math
import os
import re
import subprocess
import sys
import time

CF = getattr(subprocess, "CREATE_NO_WINDOW", 0)  # sembunyikan jendela console di Windows
CHUNK = 1 << 20  # 1 MiB, kelipatan 4 dan 8 byte (frame float32 mono/stereo)

_FF = None


class Cancelled(Exception):
    pass


def app_dir():
    """Folder tempat aplikasi berada (folder .exe jika sudah dibuild)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def result_dir():
    d = os.path.join(app_dir(), "Hasil")
    os.makedirs(d, exist_ok=True)
    return d


def ffmpeg_exe():
    global _FF
    if _FF:
        return _FF
    try:
        import imageio_ffmpeg
        _FF = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        import shutil
        _FF = shutil.which("ffmpeg")
    if not _FF:
        raise RuntimeError("ffmpeg tidak ditemukan.")
    return _FF


def probe(path):
    p = subprocess.run([ffmpeg_exe(), "-hide_banner", "-i", path],
                       stderr=subprocess.PIPE, stdout=subprocess.DEVNULL,
                       stdin=subprocess.DEVNULL, creationflags=CF)
    s = p.stderr.decode("utf-8", "replace")
    a = re.search(r"Audio:\s*([^\s,]+).*?(\d+) Hz,\s*([^,\n]+)", s)
    if not a:
        raise ValueError("Bukan file audio yang valid: " + os.path.basename(path))
    layout = a.group(3).strip().lower()
    ch = 1 if (layout.startswith("mono") or layout.startswith("1 channel")) else 2
    d = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", s)
    dur = 0.0
    if d:
        dur = int(d.group(1)) * 3600 + int(d.group(2)) * 60 + float(d.group(3))
    return {"codec": a.group(1), "rate": int(a.group(2)), "channels": ch, "duration": dur}


def out_ext(path_or_ext):
    e = path_or_ext.lower()
    if not e.startswith("."):
        e = os.path.splitext(e)[1]
    if e in (".mp3", ".wav"):
        return e
    return ".m4a"  # m4a / mp4a / aac / mp4 -> keluaran .m4a


def codec_args(ext, src_codec=None):
    if ext == ".mp3":
        return ["-c:a", "libmp3lame", "-q:a", "0"]
    if ext == ".wav":
        c = src_codec if src_codec in ("pcm_s16le", "pcm_s24le", "pcm_s32le") else "pcm_s16le"
        return ["-c:a", c]
    return ["-c:a", "aac", "-b:a", "256k"]


def _start_decoder(path, rate, ch):
    return subprocess.Popen(
        [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-i", path, "-vn",
         "-f", "f32le", "-ar", str(rate), "-ac", str(ch), "pipe:1"],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
        creationflags=CF)


def _start_encoder(out, rate, ch, ext, src_codec=None):
    return subprocess.Popen(
        [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y",
         "-f", "f32le", "-ar", str(rate), "-ac", str(ch), "-i", "pipe:0",
         *codec_args(ext, src_codec), out],
        stdin=subprocess.PIPE, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL,
        creationflags=CF)


def _finish_encoder(enc):
    enc.stdin.close()
    err = enc.stderr.read().decode("utf-8", "replace")
    enc.wait()
    if enc.returncode:
        raise RuntimeError("Encoder gagal: " + err.strip())


def _kill(*procs):
    for p in procs:
        if p is not None and p.poll() is None:
            try:
                p.kill()
            except Exception:
                pass
    for p in procs:
        if p is not None:
            for s in (p.stdin, p.stdout, p.stderr):
                try:
                    if s:
                        s.close()
                except Exception:
                    pass


def _rm(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def cut(path, seg_seconds, outdir, progress=lambda f: None, log=lambda s: None,
        cancelled=lambda: False):
    """Potong satu file menjadi bagian-bagian berdurasi seg_seconds (bagian terakhir sisa)."""
    info = probe(path)
    rate, ch = info["rate"], info["channels"]
    ext = out_ext(path)
    frame = ch * 4
    seg_samples = max(1, int(round(seg_seconds * rate)))
    if ext == ".m4a":
        # AAC bekerja per frame 1024 sampel; bulatkan ke bawah agar potongan tidak
        # punya padding di ujung dan tetap menyambung rapat saat digabung.
        seg_samples = max(1024, seg_samples // 1024 * 1024)
    seg_bytes = seg_samples * frame
    total_bytes = max(1, int(info["duration"] * rate) * frame)
    nparts = max(1, math.ceil(info["duration"] * rate / seg_samples)) if info["duration"] else 0
    base = os.path.splitext(os.path.basename(path))[0]
    os.makedirs(outdir, exist_ok=True)

    dec = _start_decoder(path, rate, ch)
    enc = None
    out = None
    outs = []
    in_part = done = part = 0
    try:
        while True:
            if cancelled():
                raise Cancelled()
            chunk = dec.stdout.read(min(seg_bytes - in_part, CHUNK))
            if not chunk:
                break
            if enc is None:
                part += 1
                out = os.path.join(outdir, f"{base}_bagian{part:03d}{ext}")
                enc = _start_encoder(out, rate, ch, ext, info["codec"])
                log(f"Memotong bagian {part}" + (f"/{nparts}" if nparts else "") + " ...")
            enc.stdin.write(chunk)
            in_part += len(chunk)
            done += len(chunk)
            if in_part >= seg_bytes:
                _finish_encoder(enc)
                outs.append(out)
                enc = None
                in_part = 0
            progress(min(1.0, done / total_bytes))
        if enc is not None:
            _finish_encoder(enc)
            outs.append(out)
            enc = None
        dec.wait()
        if dec.returncode:
            raise RuntimeError("Gagal membaca file audio.")
        progress(1.0)
        return outs
    except BaseException:
        _kill(dec, enc)
        _rm(out if enc is not None or out not in outs else None)
        raise
    finally:
        _kill(dec)


def merge(files, outdir, out_fmt=None, progress=lambda f: None, log=lambda s: None,
          cancelled=lambda: False):
    """Gabungkan banyak file menjadi satu tanpa jeda sama sekali."""
    if len(files) < 2:
        raise ValueError("Pilih minimal 2 file untuk digabung.")
    infos = [probe(f) for f in files]
    rate = max(i["rate"] for i in infos)
    ch = min(2, max(i["channels"] for i in infos))
    ext = out_ext(out_fmt) if out_fmt else out_ext(files[0])
    total = sum(i["duration"] for i in infos) or 1.0
    os.makedirs(outdir, exist_ok=True)
    out = os.path.join(outdir, "gabungan_" + time.strftime("%Y%m%d_%H%M%S") + ext)

    enc = _start_encoder(out, rate, ch, ext, infos[0]["codec"])
    dec = None
    bytes_per_sec = rate * ch * 4
    done = 0
    try:
        for n, (f, info) in enumerate(zip(files, infos), 1):
            log(f"Menggabungkan {n}/{len(files)}: {os.path.basename(f)}")
            dec = _start_decoder(f, rate, ch)
            while True:
                if cancelled():
                    raise Cancelled()
                chunk = dec.stdout.read(CHUNK)
                if not chunk:
                    break
                enc.stdin.write(chunk)
                done += len(chunk)
                progress(min(0.99, done / bytes_per_sec / total))
            dec.wait()
            if dec.returncode:
                raise RuntimeError("Gagal membaca: " + os.path.basename(f))
            dec = None
        _finish_encoder(enc)
        progress(1.0)
        return [out]
    except BaseException:
        _kill(dec, enc)
        _rm(out)
        raise
